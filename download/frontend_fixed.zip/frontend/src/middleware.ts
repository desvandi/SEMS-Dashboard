import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import crypto from 'crypto';

const COOKIE_SECRET = process.env.COOKIE_SECRET || 'sems-default-secret-change-me';
const COOKIE_MAX_AGE_MS = 24 * 60 * 60 * 1000; // 24 hours

/**
 * Fix #3: Verify the signed auth cookie instead of checking for the forgeable
 * "sems-auth=1" literal. The cookie now contains:
 *   base64(username:timestamp:HMAC-SHA256(username:timestamp, secret))
 *
 * Also removes the NextAuth session-token check (Fix #10).
 */
export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Protect all dashboard routes from unauthenticated access
  if (pathname.startsWith('/dashboard')) {
    const semsAuth = request.cookies.get('sems-auth');

    if (!semsAuth?.value) {
      const loginUrl = new URL('/login', request.url);
      loginUrl.searchParams.set('callbackUrl', pathname);
      return NextResponse.redirect(loginUrl);
    }

    try {
      const decoded = Buffer.from(semsAuth.value, 'base64').toString('utf-8');
      const parts = decoded.split(':');

      // Expected: username:timestamp:signature
      if (parts.length < 3) {
        throw new Error('Invalid cookie format');
      }

      const username = parts.slice(0, -2).join(':'); // username may contain ':'
      const timestamp = parts[parts.length - 2];
      const signature = parts[parts.length - 1];

      // Check timestamp freshness (24h max age)
      const age = Date.now() - parseInt(timestamp, 10);
      if (isNaN(age) || age > COOKIE_MAX_AGE_MS || age < 0) {
        throw new Error('Cookie expired');
      }

      // Verify HMAC signature
      const payload = `${username}:${timestamp}`;
      const expectedSig = crypto
        .createHmac('sha256', COOKIE_SECRET)
        .update(payload)
        .digest('hex');

      if (signature !== expectedSig) {
        throw new Error('Invalid signature');
      }

      // Signature valid — allow access
    } catch {
      // Invalid or expired cookie — redirect to login
      const loginUrl = new URL('/login', request.url);
      loginUrl.searchParams.set('callbackUrl', pathname);
      return NextResponse.redirect(loginUrl);
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    '/dashboard/:path*',
  ],
};
