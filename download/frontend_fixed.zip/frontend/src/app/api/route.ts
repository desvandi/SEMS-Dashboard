import { NextResponse } from "next/server";

// Fix #14: Replace "Hello World" with a proper health check endpoint
export async function GET() {
  return NextResponse.json({ status: 'ok', service: 'SEMS Frontend' });
}
