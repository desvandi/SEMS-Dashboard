import { NextRequest, NextResponse } from 'next/server';
import { gasFetch } from '@/lib/gas-fetch';
import { cookies } from 'next/headers';
import crypto from 'crypto';

// FE-L-09: GAS_URL is available server-side only; client uses the proxy at /api/sems
const GAS_URL = process.env.GAS_SCRIPT_URL;
const COOKIE_SECRET = process.env.COOKIE_SECRET || 'sems-default-secret-change-me';

export async function GET(request: NextRequest) {
  return handleRequest(request, 'GET');
}

export async function POST(request: NextRequest) {
  return handleRequest(request, 'POST');
}

async function handleRequest(request: NextRequest, method: string) {
  if (!GAS_URL) {
    return NextResponse.json(
      { success: false, error: 'GAS_SCRIPT_URL not configured' },
      { status: 500 }
    );
  }

  // CSRF protection for POST requests (Fix #5)
  if (method === 'POST') {
    const csrfHeader = request.headers.get('X-CSRF-Token');
    const csrfCookie = (await cookies()).get('sems-csrf');

    if (!csrfHeader || !csrfCookie || csrfHeader !== csrfCookie.value) {
      return NextResponse.json(
        { success: false, error: 'CSRF validation failed' },
        { status: 403 }
      );
    }
  }

  // FE-M-06: Add 15s timeout to prevent hanging requests
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000);

  try {
    const { searchParams } = new URL(request.url);
    const path = searchParams.get('path');

    const gasUrl = new URL(GAS_URL);

    let body: string | null = null;
    const headers: Record<string, string> = {};

    const authToken = request.headers.get('X-Auth-Token');

    if (method === 'POST') {
      const clonedBody = await request.json();
      clonedBody.path = path;
      // FIX #1: Put token in request body instead of URL for POST requests.
      // This prevents the token from appearing in server logs, browser history,
      // and referrer headers.
      if (authToken) {
        clonedBody.token = authToken;
      }
      body = JSON.stringify(clonedBody);
      if (path) gasUrl.searchParams.set('path', path);
    } else {
      if (path) gasUrl.searchParams.set('path', path);
      for (const [key, value] of searchParams.entries()) {
        if (key !== 'path' && key !== 'XTransformPort' && ['page', 'limit', 'offset', 'status'].includes(key)) {
          gasUrl.searchParams.set(key, value);
        }
      }
    }

    // FIX #1: Auth token is sent ONLY via headers (never in URL query params).
    // For GET requests, the GAS 302 redirect to script.googleusercontent.com
    // strips custom headers. This is an accepted limitation.
    //
    // MITIGATION: Restrict GAS Web App access to server IP(s) via GAS deploy
    // settings or Google Cloud IAP, so the URL without a token header cannot
    // be replayed from arbitrary locations.
    if (authToken) {
      headers['X-Auth-Token'] = authToken;
      // NO: gasUrl.searchParams.set('token', authToken) — removed for security
    }
    headers['Content-Type'] = 'application/json';

    // Generate and set CSRF token cookie if not present (Fix #5)
    const cookieStore = await cookies();
    const existingCsrf = cookieStore.get('sems-csrf');
    if (!existingCsrf) {
      const csrfToken = crypto.randomBytes(32).toString('hex');
      cookieStore.set('sems-csrf', csrfToken, {
        path: '/',
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 86400,
      });
    }

    // Use gasFetch to correctly handle GAS 302 redirects for all requests
    const response = await gasFetch(gasUrl.toString(), {
      method,
      headers,
      body,
      signal: controller.signal,
    });

    clearTimeout(timeoutId);
    const data = await response.json();
    return NextResponse.json(data, { status: response.ok ? 200 : response.status });
  } catch (error) {
    clearTimeout(timeoutId);
    if (error instanceof DOMException && error.name === 'AbortError') {
      return NextResponse.json(
        { success: false, error: 'Backend request timed out' },
        { status: 504 }
      );
    }
    // FE-L-06: Log error server-side only, don't expose internal details
    console.error('SEMS API proxy error:', error instanceof Error ? error.message : 'Unknown error');
    return NextResponse.json(
      { success: false, error: 'Failed to connect to backend service' },
      { status: 502 }
    );
  }
}
