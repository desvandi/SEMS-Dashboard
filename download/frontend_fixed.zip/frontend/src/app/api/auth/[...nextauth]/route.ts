import { NextAuth } from 'next-auth';

// Fix #10: NextAuth route stub. All authentication is now handled via the
// custom SEMS auth flow. This file exists to prevent route resolution errors.
// The handler returns a 410 Gone to indicate this endpoint is deprecated.
export async function GET() {
  return new Response(
    JSON.stringify({ error: 'NextAuth is deprecated. Use /api/sems?path=api/users/auth for login.' }),
    { status: 410, headers: { 'Content-Type': 'application/json' } }
  );
}

export async function POST() {
  return new Response(
    JSON.stringify({ error: 'NextAuth is deprecated. Use /api/sems?path=api/users/auth for login.' }),
    { status: 410, headers: { 'Content-Type': 'application/json' } }
  );
}
