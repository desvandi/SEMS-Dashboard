import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';

const COOKIE_SECRET = process.env.COOKIE_SECRET || 'sems-default-secret-change-me';

/**
 * POST /api/auth/set-cookie
 *
 * Fix #3: Generates a signed cookie value that the middleware can verify.
 * The cookie value is: base64(username + ":" + HMAC-SHA256(username + timestamp, secret))
 * The timestamp is also embedded in the cookie so the middleware can check freshness.
 *
 * Request body: { username: string }
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const username = body?.username;

    if (!username || typeof username !== 'string') {
      return NextResponse.json(
        { success: false, error: 'Username required' },
        { status: 400 }
      );
    }

    const timestamp = Date.now().toString();
    const payload = `${username}:${timestamp}`;
    const signature = crypto
      .createHmac('sha256', COOKIE_SECRET)
      .update(payload)
      .digest('hex');

    const cookieValue = Buffer.from(`${payload}:${signature}`).toString('base64');

    const response = NextResponse.json({ success: true });
    response.cookies.set('sems-auth', cookieValue, {
      path: '/',
      maxAge: 86400, // 24 hours
      httpOnly: false, // needs to be readable by middleware (which has access)
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
    });

    return response;
  } catch {
    return NextResponse.json(
      { success: false, error: 'Failed to set auth cookie' },
      { status: 500 }
    );
  }
}
